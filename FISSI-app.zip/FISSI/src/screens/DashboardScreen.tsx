import React, { useMemo, useState } from 'react';
import { RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { ActivityIndicator, FAB, Text, useTheme } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSubscriptions } from '../context/SubscriptionsContext';
import { RootStackParamList } from '../navigation/types';
import { StatCard } from '../components/StatCard';
import { SubscriptionCard } from '../components/SubscriptionCard';
import {
  overdueSubscriptions,
  subscriptionsDueThisMonth,
  paymentsInCurrentMonth,
  sumAmount,
  formatCurrency,
} from '../utils/selectors';
import { monthLabel } from '../utils/dates';

export function DashboardScreen() {
  const theme = useTheme();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { subscriptions, paymentLog, loading, refresh, markAsPaid } = useSubscriptions();
  const [refreshing, setRefreshing] = useState(false);

  const dueThisMonth = useMemo(() => subscriptionsDueThisMonth(subscriptions), [subscriptions]);
  const overdue = useMemo(() => overdueSubscriptions(subscriptions), [subscriptions]);
  const paymentsThisMonth = useMemo(() => paymentsInCurrentMonth(paymentLog), [paymentLog]);

  const remainingTotal = useMemo(() => sumAmount(dueThisMonth), [dueThisMonth]);
  const paidTotal = useMemo(() => sumAmount(paymentsThisMonth), [paymentsThisMonth]);
  const committedTotal = remainingTotal + paidTotal;

  const handleRefresh = async () => {
    setRefreshing(true);
    await refresh();
    setRefreshing(false);
  };

  if (loading && subscriptions.length === 0) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
      >
        <Text variant="titleMedium" style={styles.monthLabel}>
          {monthLabel()}
        </Text>
        <Text variant="headlineSmall" style={styles.heading}>
          Situazione del mese
        </Text>

        <View style={styles.statsRow}>
          <StatCard
            label="Ancora da pagare"
            value={formatCurrency(remainingTotal)}
            tone={remainingTotal > 0 ? 'warning' : 'default'}
          />
          <StatCard label="Già pagato" value={formatCurrency(paidTotal)} tone="success" />
        </View>
        <View style={styles.statsRow}>
          <StatCard label="Totale impegnato nel mese" value={formatCurrency(committedTotal)} />
        </View>

        {overdue.length > 0 && (
          <View style={styles.overdueBanner}>
            <Text style={{ color: theme.colors.error, fontWeight: '700' }}>
              ⚠️ {overdue.length} {overdue.length === 1 ? 'pagamento manuale in ritardo' : 'pagamenti manuali in ritardo'}
            </Text>
          </View>
        )}

        <Text variant="titleMedium" style={styles.sectionTitle}>
          Questo mese hai ancora da pagare
        </Text>

        {dueThisMonth.length === 0 ? (
          <Text variant="bodyMedium" style={styles.emptyState}>
            Nessun pagamento in sospeso per questo mese. 🎉
          </Text>
        ) : (
          dueThisMonth.map((sub) => (
            <SubscriptionCard
              key={sub.id}
              subscription={sub}
              onPress={() => navigation.navigate('SubscriptionDetail', { subscriptionId: sub.id })}
              onMarkAsPaid={sub.payment_type === 'manual' ? () => markAsPaid(sub) : undefined}
            />
          ))
        )}
      </ScrollView>

      <FAB
        icon="plus"
        style={[styles.fab, { backgroundColor: theme.colors.primary }]}
        color="#fff"
        onPress={() => navigation.navigate('SubscriptionForm', undefined)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 100,
  },
  monthLabel: {
    opacity: 0.6,
  },
  heading: {
    fontWeight: '800',
    marginBottom: 16,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  overdueBanner: {
    backgroundColor: '#FDECEA',
    borderRadius: 12,
    padding: 12,
    marginTop: 8,
    marginBottom: 8,
  },
  sectionTitle: {
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 12,
  },
  emptyState: {
    opacity: 0.6,
    marginTop: 8,
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 24,
    borderRadius: 28,
  },
});
