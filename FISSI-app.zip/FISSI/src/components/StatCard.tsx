import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Text, useTheme } from 'react-native-paper';

interface StatCardProps {
  label: string;
  value: string;
  tone?: 'default' | 'warning' | 'success';
}

export function StatCard({ label, value, tone = 'default' }: StatCardProps) {
  const theme = useTheme();

  const toneColor =
    tone === 'warning' ? theme.colors.error : tone === 'success' ? '#2E7D32' : theme.colors.primary;

  return (
    <View style={[styles.card, { backgroundColor: theme.colors.elevation.level1 }]}>
      <Text variant="labelMedium" style={styles.label}>
        {label}
      </Text>
      <Text variant="headlineSmall" style={[styles.value, { color: toneColor }]}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 14,
    minWidth: 140,
  },
  label: {
    opacity: 0.7,
    marginBottom: 4,
  },
  value: {
    fontWeight: '700',
  },
});
