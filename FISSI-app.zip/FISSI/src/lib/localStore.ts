import AsyncStorage from '@react-native-async-storage/async-storage';
import { PaymentLogEntry, Subscription } from '../types';

const KEYS = {
  subscriptions: 'fissi:subscriptions',
  paymentLog: 'fissi:paymentLog',
};

export async function loadSubscriptions(): Promise<Subscription[]> {
  const raw = await AsyncStorage.getItem(KEYS.subscriptions);
  if (!raw) return [];
  try {
    return JSON.parse(raw) as Subscription[];
  } catch {
    return [];
  }
}

export async function saveSubscriptions(list: Subscription[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.subscriptions, JSON.stringify(list));
}

export async function loadPaymentLog(): Promise<PaymentLogEntry[]> {
  const raw = await AsyncStorage.getItem(KEYS.paymentLog);
  if (!raw) return [];
  try {
    return JSON.parse(raw) as PaymentLogEntry[];
  } catch {
    return [];
  }
}

export async function savePaymentLog(list: PaymentLogEntry[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.paymentLog, JSON.stringify(list));
}
