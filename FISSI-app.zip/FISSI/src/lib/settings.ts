import AsyncStorage from '@react-native-async-storage/async-storage';

const REMINDER_LEAD_DAYS_KEY = 'fissi:reminderLeadDays';
export const DEFAULT_REMINDER_LEAD_DAYS = 3;

export async function getReminderLeadDays(): Promise<number> {
  const stored = await AsyncStorage.getItem(REMINDER_LEAD_DAYS_KEY);
  if (!stored) return DEFAULT_REMINDER_LEAD_DAYS;
  const parsed = parseInt(stored, 10);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : DEFAULT_REMINDER_LEAD_DAYS;
}

export async function setReminderLeadDays(days: number): Promise<void> {
  await AsyncStorage.setItem(REMINDER_LEAD_DAYS_KEY, String(days));
}
