import dayjs, { Dayjs } from 'dayjs';
import 'dayjs/locale/it';
import { BillingCycle } from '../types';

dayjs.locale('it');

/** Formato standard usato per le colonne "date" su Supabase (YYYY-MM-DD). */
export const DATE_FORMAT = 'YYYY-MM-DD';

export function today(): Dayjs {
  return dayjs().startOf('day');
}

export function toDateOnly(date: string | Dayjs): string {
  return dayjs(date).format(DATE_FORMAT);
}

/**
 * Calcola la scadenza successiva a partire da una data e da un ciclo di
 * fatturazione. Per i cicli mensili/trimestrali/annuali usa l'aritmetica
 * dei mesi di dayjs, che gestisce correttamente i mesi con lunghezza
 * diversa (es. 31 gennaio + 1 mese = 28/29 febbraio).
 */
export function computeNextDueDate(
  fromDate: string,
  cycle: BillingCycle,
  customIntervalDays?: number | null
): string {
  const base = dayjs(fromDate);

  switch (cycle) {
    case 'weekly':
      return toDateOnly(base.add(1, 'week'));
    case 'monthly':
      return toDateOnly(base.add(1, 'month'));
    case 'quarterly':
      return toDateOnly(base.add(3, 'month'));
    case 'yearly':
      return toDateOnly(base.add(1, 'year'));
    case 'custom_days': {
      const days = customIntervalDays && customIntervalDays > 0 ? customIntervalDays : 30;
      return toDateOnly(base.add(days, 'day'));
    }
    default:
      return toDateOnly(base.add(1, 'month'));
  }
}

/**
 * Fa avanzare `next_due_date` finché non è >= oggi, restituendo la nuova
 * data e il numero di occorrenze "saltate" (cioè quante volte il ciclo è
 * scattato mentre l'app non veniva aperta). Usata per riconciliare i
 * pagamenti automatici.
 */
export function advanceUntilFuture(
  dueDate: string,
  cycle: BillingCycle,
  customIntervalDays: number | null | undefined,
  referenceDate: Dayjs = today()
): { newDueDate: string; occurrencesPassed: string[] } {
  const occurrencesPassed: string[] = [];
  let current = dueDate;
  let guard = 0;

  while (dayjs(current).isBefore(referenceDate) && guard < 1000) {
    occurrencesPassed.push(current);
    current = computeNextDueDate(current, cycle, customIntervalDays);
    guard += 1;
  }

  return { newDueDate: current, occurrencesPassed };
}

export function isSameMonth(dateStr: string, reference: Dayjs = today()): boolean {
  const d = dayjs(dateStr);
  return d.year() === reference.year() && d.month() === reference.month();
}

export function isOverdue(dateStr: string, reference: Dayjs = today()): boolean {
  return dayjs(dateStr).isBefore(reference, 'day');
}

export function isDueToday(dateStr: string, reference: Dayjs = today()): boolean {
  return dayjs(dateStr).isSame(reference, 'day');
}

export function daysUntil(dateStr: string, reference: Dayjs = today()): number {
  return dayjs(dateStr).startOf('day').diff(reference, 'day');
}

export function formatItalianDate(dateStr: string): string {
  return dayjs(dateStr).format('D MMMM YYYY');
}

export function formatShortDate(dateStr: string): string {
  return dayjs(dateStr).format('DD/MM/YYYY');
}

export function monthLabel(reference: Dayjs = today()): string {
  const label = reference.format('MMMM YYYY');
  return label.charAt(0).toUpperCase() + label.slice(1);
}
