import { PaymentLogEntry, Subscription } from '../types';
import { isOverdue, isSameMonth, today } from './dates';

/** Abbonamenti la cui prossima scadenza cade nel mese corrente (ancora da pagare). */
export function subscriptionsDueThisMonth(subscriptions: Subscription[]): Subscription[] {
  const ref = today();
  return subscriptions
    .filter((s) => s.active && isSameMonth(s.next_due_date, ref))
    .sort((a, b) => (a.next_due_date < b.next_due_date ? -1 : 1));
}

export function overdueSubscriptions(subscriptions: Subscription[]): Subscription[] {
  const ref = today();
  return subscriptions.filter((s) => s.active && s.payment_type === 'manual' && isOverdue(s.next_due_date, ref));
}

/** Pagamenti registrati (log) la cui scadenza di riferimento cade nel mese corrente. */
export function paymentsInCurrentMonth(paymentLog: PaymentLogEntry[]): PaymentLogEntry[] {
  const ref = today();
  return paymentLog.filter((p) => isSameMonth(p.due_date, ref));
}

export function sumAmount(subscriptions: Array<Pick<Subscription, 'amount'>>): number {
  return subscriptions.reduce((acc, s) => acc + Number(s.amount), 0);
}

export function formatCurrency(amount: number, currency = 'EUR'): string {
  try {
    return new Intl.NumberFormat('it-IT', { style: 'currency', currency }).format(amount);
  } catch {
    return `${amount.toFixed(2)} ${currency}`;
  }
}
